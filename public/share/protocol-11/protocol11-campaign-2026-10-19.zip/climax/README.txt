Protocol 11 — Climax (full Classic)
27.5 seconds · 1080×1920 · 60 fps · H.264 / AAC

The film is one continuous native capture of the prepared final turn of a complete seeded Classic match: eleven Protocols, seventeen rounds, every physical card conserved. The visible discard draw, the run and colour staging, the Protocol lay-down, the 12 hit and the final discard all execute through the live production engine and native controls; the round and match settlement are the real result. No game UI is repainted and no outcome is fabricated.

This is a seeded automated demonstration, not a recorded human or competitive result, and the viewport is browser emulation rather than a physical iPhone recording. Source, edit, audio and QC facts live in provenance.json and manifest.json; render inputs are hash-bound in render-receipt.json.

Music: Protocol Runner by loftwah (MP cleared promotional use on 6 October 2026). Card sounds: Kenney pack, CC0 (licence included). Nunito: OFL (licence included).

The deployed pack carries the film, the three stills and the text, source and manifest files. The local command also writes a contact sheet and a one-file ZIP under tools/remotion-promo/renders/ for convenience; they stay outside the deployed assets so the game bundle keeps its size rail.

Watch with sound, check the platform crop and paste caption.txt, hooks.txt and alt-text.txt before posting. Posting remains human-controlled; no account is required to download.
