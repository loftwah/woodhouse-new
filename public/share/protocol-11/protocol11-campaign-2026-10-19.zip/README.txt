Protocol 11 campaign pack — 19 October 2026

Three films, all from one seeded full-Classic match captured on the deployed game
(https://protocol11.loftwah.com), plus the stills, captions, hooks, alt text and
source records each one needs.

  climax/     Eleven Protocols. One last turn.      27.5 s · 1080×1920 · 60 fps
  decision/   Take the eleven?                      17.5 s · 1080×1920 · 30 fps
  threat/     A rival. One card.                    11.5 s · 1080×1920 · 30 fps

What each film shows, and what it does not
  climax    the final turn of the match: take the visible eleven, build run
            8–11 and a five-card colour group, lay Protocol 11, extend the run
            with the twelve, discard the last card, the round win and the final
            standings. It is a seeded demonstration, not a competitive result.
  decision  the choice at that same final turn — take the visible eleven or draw
            from the deck — and the consequence of taking it: the run completes
            and Protocol 11 goes down. It stops at the lay-down: no hit, no
            discard and no result are claimed.
  threat    an earlier moment of the same match: Zadie has her Protocol down and
            one card left, and the Skip is played at her, costing her the turn
            while she still holds that card. It does not claim she would have
            won, that the round ended, or any match outcome.

Sound
  An excerpt of the cleared Protocol Runner track by loftwah, under the game's
  own first-party card sounds. Every cue is placed through the shot trim and
  retime it belongs to, so the sound follows the edited picture; each pack's
  provenance.json records the cue instants and the ones its edit does not show.

Rights and provenance
  Original artwork, original soundtrack, CC0 sound effects (Kenney). Each pack
  carries its own provenance.json, render-receipt.json, licences and manifest.
  The films are promotional assets: check the final crop, audio and link on the
  platform you post to.
