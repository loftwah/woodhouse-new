Protocol 11 — The Skip — a rival with one card
11.5 seconds · 1080×1920 · 30 fps · H.264 / AAC

The prepared earlier moment of the seeded full-Classic match: a legal Skip discarded at Zadie while she holds one card, and the skip the table shows.

Seeded automated demonstration, not a recorded human or competitive result.
Phone viewport emulation, not a physical iPhone recording.
The opening Skip card is composed artwork matching the printed Skip card; every other shot is captured production pixels.
The film shows the Skip and the skip notice, and the target still holding her card. It does not claim she would have won the round, that the round ended, or any match outcome.
This is an earlier round of the same seeded match, not the sequence immediately before the decision short.

The film is a deliberate short edit of a verified native capture of a seeded full-Classic demonstration. Shots are trimmed and retimed intervals of the captured production pixels; music and the observed first-party sounds are mixed at output-timeline instants mapped through each shot's trim. Source, edit, audio and QC facts live in provenance.json and manifest.json; the render inputs are hash-bound in render-receipt.json.

Music: Protocol Runner by loftwah (MP cleared promotional use on 6 October 2026). Card sounds: Kenney pack, CC0 (licence included). Nunito: OFL (licence included).

Watch with sound, check the destination platform crop and paste caption.txt, hooks.txt and alt-text.txt before posting. Posting remains human-controlled, and no account is required to download.
