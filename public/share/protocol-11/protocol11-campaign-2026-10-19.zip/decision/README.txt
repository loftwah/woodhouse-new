Protocol 11 — One last turn — the decision
17.5 seconds · 1080×1920 · 30 fps · H.264 / AAC

The prepared final turn of the seeded full-Classic match: taking the visible 11 completes the run 8–11 and lays down Protocol 11.

Seeded automated demonstration, not a recorded human or competitive result.
Phone viewport emulation, not a physical iPhone recording.
The opening 11 card is composed artwork matching the visible discard; every other shot is captured production pixels.
The film shows the decision and the Protocol 11 lay-down only. It does not show the 12 hit, the discard or the match result, and claims none of them.

The film is a deliberate short edit of a verified native capture of a seeded full-Classic demonstration. Shots are trimmed and retimed intervals of the captured production pixels; music and the observed first-party sounds are mixed at output-timeline instants mapped through each shot's trim. Source, edit, audio and QC facts live in provenance.json and manifest.json; the render inputs are hash-bound in render-receipt.json.

Music: Protocol Runner by loftwah (MP cleared promotional use on 6 October 2026). Card sounds: Kenney pack, CC0 (licence included). Nunito: OFL (licence included).

Watch with sound, check the destination platform crop and paste caption.txt, hooks.txt and alt-text.txt before posting. Posting remains human-controlled, and no account is required to download.
