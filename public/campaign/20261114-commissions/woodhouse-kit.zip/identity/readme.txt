Published project mark, from the Factory Atlas source inventory.
Native Woodhouse seal. Loom Display is used on the site; the font is not redistributed here.
Project: /
