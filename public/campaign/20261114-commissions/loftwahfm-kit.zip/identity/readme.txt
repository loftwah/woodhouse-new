No cleared official mark included. Illustrative studies are not an official identity.
Project: https://fm.loftwah.com/
