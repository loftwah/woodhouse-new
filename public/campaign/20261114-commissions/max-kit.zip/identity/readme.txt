Published project mark, from the Factory Atlas source inventory.
Project: https://max.loftwah.com/
