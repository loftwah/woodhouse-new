Published project mark, from the Factory Atlas source inventory.
Project: /projects/social-club/
