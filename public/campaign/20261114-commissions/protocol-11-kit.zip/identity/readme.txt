Published project mark, from the Factory Atlas source inventory.
Project: https://protocol11.loftwah.com/
