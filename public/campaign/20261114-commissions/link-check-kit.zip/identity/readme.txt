Published project mark, from the Factory Atlas source inventory.
Project: https://share.loftwah.com/
