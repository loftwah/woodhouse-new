Published project mark, from the Factory Atlas source inventory.
Project: https://liferaft.loftwah.com/
