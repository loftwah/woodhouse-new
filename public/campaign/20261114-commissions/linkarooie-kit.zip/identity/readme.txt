Published project mark, from the Factory Atlas source inventory.
Accepted lime curator via the LDraw catalogue.
Project: https://showcase.loftwah.com/
