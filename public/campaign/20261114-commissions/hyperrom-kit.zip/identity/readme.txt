No cleared official mark included. Illustrative studies are not an official identity.
Project: /share/?artType=commissioned&artTag=HyperROM
