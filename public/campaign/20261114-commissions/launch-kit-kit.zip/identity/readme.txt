No cleared official mark included. Illustrative studies are not an official identity.
Project: https://composer.loftwah.com/launch-kit
